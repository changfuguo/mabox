/**
 * @file 排行榜页
 * @authors lvjiran
 * @date    2016-01-13 15:41:45
 * @version 1.0
 */
var util = require('ss:widget/base/util.js');
var stat = require('ss:widget/stat/stat.js');

module.exports = {
    /**
     * 当前页统计参数
     */
    statParam: {
        // 排行榜页
        'showRankpg': {
            'da_src': 'ssrankpg',
            'da_act': 'show'
        },
        // 头部/底部去搜索按钮点击
        'searchBtnClick': {
            'da_src': 'ssrankpg.searchbt',
            'da_act': 'click'
        },
        // 分类排行榜列表点击
        'rankListClick': {
            'da_src': 'ssrankpg.ranklistitem',
            'da_act': 'click'
        },
        // 分类排行榜tab0点击
        'rankBtnClick0': {
            'da_src': 'ssrankpg.rankbt0',
            'da_act': 'click'
        },
        // 分类排行榜tab1点击
        'rankBtnClick1': {
            'da_src': 'ssrankpg.rankbt1',
            'da_act': 'click'
        },
        // 分类排行榜tab2点击
        'rankBtnClick2': {
            'da_src': 'ssrankpg.rankbt2',
            'da_act': 'click'
        },
        // 分类排行榜tab3点击
        'rankBtnClick3': {
            'da_src': 'ssrankpg.rankbt3',
            'da_act': 'click'
        },
        // 推荐模块按钮点击
        'rmdClick': {
            'da_src': 'ssrankpg.rmdbt',
            'da_act': 'click'
        }
    },
    /**
     * 获取浏览器内核信息
     */
    'ua': navigator.userAgent.toLowerCase(),

    /**
     * 事件绑定
     */
    bindEvent: function () {
        var me = this;

        // 头部/底部搜索按钮点击
        $(document.body).on('click', '.act-search', function () {
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['searchBtnClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['searchBtnClick']);
            }
        });
        // 分类排行榜tab0点击
        $(document.body).on('click', '#rank-tab-0', function () {
            stat.addStat(me.statParam['rankBtnClick0']);
        });
        // 分类排行榜tab1点击
        $(document.body).on('click', '#rank-tab-1', function () {
            stat.addStat(me.statParam['rankBtnClick1']);
        });
        // 分类排行榜tab2点击
        $(document.body).on('click', '#rank-tab-2', function () {
            stat.addStat(me.statParam['rankBtnClick2']);
        });
        // 分类排行榜tab3点击
        $(document.body).on('click', '#rank-tab-3', function () {
            stat.addStat(me.statParam['rankBtnClick3']);
        });
        // 分类排行榜列表点击
        $(document.body).on('click', '.act-list-container .act-list', function () {
            var activeTabOrder = $('#rank-nav li.active').attr('data-order');
            var statCode = me.statParam['rankListClick'];
            if (activeTabOrder) {
                statCode['da_src'] = statCode['da_src'] + '_tab' + activeTabOrder;
            }
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, statCode);
            } else {
                stat.normalOpenAndStat(webAppUrl, statCode);
            }
        });
        // 推荐模块按钮点击
        $(document.body).on('click', '.rmd-list li a', function () {
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['rmdClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['rmdClick']);
            }
        });
    },

    /**
     * 初始化页面
     */
    init: function () {
        var me = this;
        me.bindEvent();
        util.wappassLoginSync();
        // 排行榜页统计pv/uv
        /* 统计pv和uv的代码放到page/rank.tpl*/
        /* stat.addStat(me.statParam['showRankpg']);*/
    }
};

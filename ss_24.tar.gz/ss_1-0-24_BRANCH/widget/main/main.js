/**
 * @file 聚合页
 * @authors lvjiran
 * @date    2015-11-17 15:31:45
 * @version 1.0
 */
var util = require('ss:widget/base/util.js');
var stat = require('ss:widget/stat/stat.js');

module.exports = {
    /**
     * 当前页统计参数
     */
    statParam : {
        // 检索聚合首页
        'showHomepg': {
            'da_src': 'sshomepg',
            'da_act': 'show'
        },
        // 头部标题文字点击
        'headTxtClick': {
            'da_src': 'sshomepg.headitem',
            'da_act': 'click'
        },
        // 筛选浮层模块列表点击
        'marskListClick': {
            'da_src': 'sshomepg.marsklistitem',
            'da_act': 'click'
        },
        // 首页模块列表点击
        'homeListClick': {
            'da_src': 'sshomepg.homelistitem',
            'da_act': 'click'
        },
        // 检索聚合tab按钮0点击
        'navBtnClick0': {
            'da_src': 'sshomepg.navbt0',
            'da_act': 'click'
        },
        // 检索聚合tab按钮1点击
        'navBtnClick1': {
            'da_src': 'sshomepg.navbt1',
            'da_act': 'click'
        }
    },
    /**
     * 获取浏览器内核信息
     */
     'ua': navigator.userAgent.toLowerCase(),
    /**
     * 事件绑定
     */
    bindEvent: function () {
        var me = this;

        // 头部标题文字点击
        $(document.body).on('click', '.info-wrapper dt', function() {
            stat.appOpenAndStat(this, me.statParam['headTxtClick']);
        });
        // 筛选浮层模块列表点击
        $(document.body).on('click', '.filter-items li', function() {
            stat.addStat(me.statParam['marskListClick']);
        });
        // 首页模块列表点击
        $(document.body).on('click', '#nav-list li', function() {
            if ($(this).hasClass('no-result')) {
                return;
            }
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') != -1 || me.ua.indexOf('baidumap_andr') != -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['homeListClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['homeListClick']);
            }
        });
        // 检索首页tab0点击
        $(document.body).on('click', '#nav-tab-0', function() {
            stat.addStat(me.statParam['navBtnClick0']);
        });
        // 检索首页tab1点击
        $(document.body).on('click', '#nav-tab-1', function() {
            stat.addStat(me.statParam['navBtnClick1']);
        });
    },
    /**
     * 初始化页面
     */
    init: function () {
        var me = this;
        me.bindEvent();
        util.wappassLoginSync();
        // 检索聚合首页统计pv/uv
        stat.addStat(me.statParam['showHomepg']);
    }
}

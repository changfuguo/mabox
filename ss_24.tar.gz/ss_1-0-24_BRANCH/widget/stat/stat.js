/**
 * @file 发送统计逻辑
 */

var util = require('ss:widget/base/util.js');

var nativeInfo = null;

/*
 * get Native info 
 *
 */

function getNativeInfo(){
    
    var promise = new RSVP.Promise(function(resolve,reject){
        if(nativeInfo){
            setTimeout(function(){
                resolve(nativeInfo);    
            },0)
        } else {
            var callback = function(data){
                nativeInfo = data;
                resolve(nativeInfo)
            }
            nativeAppAdapter.getNativeInfo(callback);
            // ingore reject methond , if not set nativeInfo we think it is web 
        } 
             
    });
    
    return promise;
}

try{
    getNativeInfo();
}catch(e){
    console.log('not opend id map');
}

function _getStatPhoneInfo() {
    
    var resid = util.getUrlQueryByKey('resid'),
        channel = util.getUrlQueryByKey('channel'),
        cuid = util.getUrlQueryByKey('cuid'),
        os = util.getUrlQueryByKey('os') || util.getUrlQueryByKey('sysdevicesystem'),
        sv = util.getUrlQueryByKey('sv') || util.getUrlQueryByKey('sysproductversion'),
        matchRes = '';
    
    var result =  {
        resid: resid,
        channel: channel,
        cuid: cuid,
        os: os,
        sv: sv
    }

    if(nativeInfo) {
        for(attr in result) {
            result[attr] = nativeInfo[attr];
        }
    } 
    if (result.os) {
        result.os = result.os.toLowerCase();
        matchRes = os.match(/(android|iphone|ipad)([\d\.]+)/gi);
        if(matchRes) {
            result.os = RegExp.$1;
            result.version = RegExp.$2;
        }
    } else {
        resutl.os = 'wap';
        result.version = '';
    }
    return result;
}
function addStat(code, phoneInfo) {
    if (!code) {
        return;
    }
    var imgUrl = 'http://client.map.baidu.com/place/v5/img/transparent_gif?';
    var opts = null;
    if (phoneInfo) {
        opts = phoneInfo;
    } else {
        opts = _getStatPhoneInfo();
    }
    //如果是webapp调用暂时不发送统计参数
    if (opts.os === 'wap') {
        return;
    }
    for (var k in code) {
        opts[k] = code[k];
    }
    for (var i in opts) {
        imgUrl += i + '=' + opts[i] + '&';
    }
    imgUrl += 't=' + Date.now();
    // 内部函数定义 - 发送统计请求
    var sendStat = function (q) {
        if (!q) {
            return;
        }
        addStat._sending = true;
        setTimeout(function () {
            $('#img')[0].src = q.src;
        }, 50);
    };
    // 内部函数定义 - 发送队列中下一个统计请求
    var reqNext = function () {
        var nq = addStat._reqQueue.shift()
        if (nq) {
            sendStat(nq);
        }
    }
    if (addStat._sending) {
        // 将本次请求加入队列
        addStat._reqQueue.push({
            src: imgUrl
        });
    } else {
        // 直接发送请求
        sendStat({
            src: imgUrl
        });
    }
    // 绑定事件
    if (!addStat._binded) {

        $('#img')[0].addEventListener('load', function () {
            addStat._sending = false;
            reqNext();
        }, false);
        $('#img')[0].addEventListener('error', function () {
            addStat._sending = false;
            reqNext();
        }, false);
        addStat._binded = true;
    }
}
/**
 * app方式加载页面并发送统计
 * @param ele
 * @param code
 */
function appOpenAndStat(ele, code) {
    var jqEle = $(ele),
        redirectUrl = jqEle.attr('data-href') || jqEle.attr('href'),
        target = ele,
        opt = {
            replace: jqEle.attr('data-replace') || false,
            containerId: jqEle.attr('data-area'),
            pagelets: jqEle.attr('data-area'),
            target: target,
            refresh: jqEle.attr('refresh') === 'true',
            cache: jqEle.attr('cache') === 'false' ? false : true
        };
    if(code) {
        addStat(code);
        setTimeout(function () {
            appPage.redirect(redirectUrl, opt);
        }, 60);
    } else {
        appPage.redirect(redirectUrl, opt);
    }
}
/**
 * 普通方式跳转页面并发送统计
 * @param url
 * @param code
 * @param replace 是否替换当前页面
 */
function normalOpenAndStat(url, code , replace) {
    if(code) {
        addStat(code);
        setTimeout(function () {
            if (replace) {
                window.location.replace(url);
            } else {
                window.location.href = url;
            }
        }, 60);
    } else {
        if (replace) {
            window.location.replace(url);
        } else {
            window.location.href = url;
        }
    }
}
// 初始化请求队列
addStat._reqQueue = [];
module.exports = {
    'getNativeInfo':getNativeInfo,
    'addStat': addStat,
    'appOpenAndStat' : appOpenAndStat,
    'normalOpenAndStat': normalOpenAndStat
};

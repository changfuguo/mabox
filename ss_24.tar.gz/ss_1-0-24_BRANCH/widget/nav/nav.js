/**
 * webapp返回导航条处理逻辑
 * Created by liumanwei on 14-5-13.
 */
module.exports = {
    /**
     * 导航的返回逻辑
     */
    back: function() {
        history.back();
    },
    /**
     * 绑定返回导航事件
     */
    bind: function() {
        var me = this;
        $('div.common-widget-nav a.back-btn').on('click', function(e) {
            me.back();
        });
    },
    /**
     * 初始化返回导航
     */
    init: function() {
        var me = this;
        me.bind();
    }
}
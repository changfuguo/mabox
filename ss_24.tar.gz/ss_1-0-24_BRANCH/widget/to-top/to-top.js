/**
 * @file 返回顶部按钮
 */
'use strict';

var IMG = __inline('/widget/to-top/gotoTop.png');
var STYLE = [
    '.go-to-top{',
    'display: none;',
    'position: absolute;',
    'bottom: 10px;',
    'right: 10px;',
    'width: 43px;',
    'height: 43px;',
    'background-image: url(' + IMG + ');',
    'background-repeat: no-repeat;',
    'background-size: 43px 43px;',
    'z-index: 10000;',
    '}'
].join('');

var btn;

/*function check() {
    if (document.body.scrollTop >= 40) {
        btn.style.display = 'block';
    } else {
        btn.style.display = 'none';
    }
}*/

function scroll(event) {
    event.preventDefault();
    window.scrollTo(0, 0);
}

function bind() {
    // window.addEventListener('scroll', check);
    btn.addEventListener('touchend', scroll);
}

function init() {
    var style;
    style = document.createElement('style');
    style.type = 'text/css';
    style.innerHTML = STYLE;
    document.head.appendChild(style);

    btn = document.createElement('div');
    btn.classList.add('go-to-top');
    document.getElementById('wrapper').appendChild(btn);

    bind();
}

exports.init = init;

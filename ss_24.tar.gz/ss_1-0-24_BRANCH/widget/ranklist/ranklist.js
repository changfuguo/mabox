/**
 * @file 排行榜页
 * @authors lvjiran
 * @date    2016-01-13 15:41:45
 * @version 1.0
 */
var util = require('ss:widget/base/util.js');
var stat = require('ss:widget/stat/stat.js');

module.exports = {
    /**
     * 当前页统计参数
     */
    statParam: {
        // 排行榜单页
        'showRankListpg': {
            'da_src': 'ssranklistpg',
            'da_act': 'show'
        },
        // 排行榜单页tab按钮0点击
        'navBtnClick0': {
            'da_src': 'ssranklistpg.navbt0',
            'da_act': 'click'
        },
        // 排行榜单页tab按钮1点击
        'navBtnClick1': {
            'da_src': 'ssranklistpg.navbt1',
            'da_act': 'click'
        },
        // 筛选浮层模块列表点击
        'marskListClick': {
            'da_src': 'ssranklistpg.marsklistitem',
            'da_act': 'click'
        },
        // 分类排行榜列表点击
        'rankListClick': {
            'da_src': 'ssranklistpg.ranklistitem',
            'da_act': 'click'
        }
    },
    /**
     * 获取浏览器内核信息
     */
    'ua': navigator.userAgent.toLowerCase(),

    /**
     * 事件绑定
     */
    bindEvent: function () {
        var me = this;

        // 排行榜单页tab0点击
        $(document.body).on('click', '#nav-tab-0', function () {
            stat.addStat(me.statParam['navBtnClick0']);
        });
        // 排行榜单页tab1点击
        $(document.body).on('click', '#nav-tab-1', function () {
            stat.addStat(me.statParam['navBtnClick1']);
        });
        // 筛选浮层模块列表点击
        $(document.body).on('click', '.filter-items li', function () {
            stat.addStat(me.statParam['marskListClick']);
        });
        // 分类排行榜列表点击
        $(document.body).on('click', '.act-list-container .act-list', function () {
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['rankListClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['rankListClick']);
            }
        });
    },

    /**
     * 初始化页面
     */
    init: function () {
        var me = this;
        me.bindEvent();
        util.wappassLoginSync();
        // 排行榜单页统计pv/uv
        stat.addStat(me.statParam['showRankListpg']);
    }
};

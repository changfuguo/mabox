/**
 * @file 分类导航
 * @authors lvjiran
 * @date    2016-01-12 15:31:45
 * @version 1.0
 */
module.exports = {

    /**
     * 阻止弹层下的页面滚动
     * @param {Object} ev 事件对象
     */
    stopScroll: function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
    },

    /**
     * 事件绑定
     */
    bindEvent: function () {
        var me = this;
        var order = null;

        // 分类导航点击事件
        $('#nav-select a').on('click', function () {
            order = $(this).index();
            $('#filterBox').removeClass('hide');
            $('#marsk').removeClass('hide');
            $('#filterBox .filter-nav a').eq(order).trigger('click');
            // 窗口内容高度固定
            var oH = $('.common-widget-nav')
                     ? document.documentElement.clientHeight - $('.common-widget-nav').height()
                     : document.documentElement.clientHeight;
            $('.wrapper').css({
                height: oH,
                overflowY: 'hidden'
            });
        });
        // 导航浮层点击tab
        $('#filterBox .filter-nav a').on('click', function () {
            var target = $(this).attr('data-href');
            $('#filterBox .filter-nav a').removeClass('active');
            $(this).addClass('active');
            $('#filterBox .filter-content-near').addClass('hide');
            $(target).removeClass('hide');
        });
        $('#marsk').on('click', function () {
            $('#filterBox').addClass('hide');
            $(this).addClass('hide');
            $('.wrapper').css({
                height: 'auto',
                overflowY: 'auto'
            });
        });
        // 阻止弹层下的页面滚动
        $('#marsk')[0].addEventListener('touchmove', me.stopScroll);
    },
    /**
     * 初始化页面
     */
    init: function () {
        var me = this;
        me.bindEvent();
    }
};
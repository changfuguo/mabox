/**
 * @file 聚合页列表
 * @authors lvjiran
 * @date    2015-11-17 15:31:45
 * @version 1.0
 */
var util = require('ss:widget/base/util.js');
var stat = require('ss:widget/stat/stat.js');


var docHeight = document.documentElement.scrollHeight;
var json = {};

/**
 * query: 请求接口参数
 * urlQuery: 获取客户端参数
 * listConfig: 列表图标颜色标识
 * pageInfo: 分页信息
 * dataOption: 筛选类别点击传参
 */

json = {
    query: '',
    urlQuery: '',
    listConfig:{},
    cityCode:''
};

json["pageInfo"] = {
    docHeight: docHeight,
    loading: '.loading',
    bottmTip: '#bottm-tip',
    ttPage: 0,
    total: 0,
    pagesize: 10,
    pageindex: 1
};

json["dataOption"] = {
    dataTag: '',
    dataScope: ''
};

/**
 * 分页逻辑
 */
function pageLogic() {
    json.pageInfo.ttPage = Math.ceil(json.pageInfo.total / json.pageInfo.pagesize);
    if(json.pageInfo.pageindex >= json.pageInfo.ttPage) {
        return;
    }
    if (json.pageInfo.total > 10) {
        on();
    }
}

/**
 * 开启滚动加载
 */
function on() {
    $(json.pageInfo.loading).show();
    window.addEventListener('scroll', autoloadList);
}

/**
 * 暂停滚动加载
 */
function off() {
    $(json.pageInfo.loading).hide();
    window.removeEventListener('scroll', autoloadList);
}

/**
 * 滚动自动加载列表
 */
function autoloadList() {
    var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
    var bottom = json.pageInfo.docHeight - document.documentElement.clientHeight;
    if (bottom - scrollTop <= 43) {
        ++json.pageInfo.pageindex;
        getNavList();
    }
}

/**
 * 发请求获取列表数据
 * @param {string} isAjax:true 点击后ajax获取列表数据
 */
function getNavList(isAjax) {
    var startTime = '';
    var endTime = '';
    var noResultHtml = null;
    
    json.pageInfo.pageindex = isAjax ? 1 : json.pageInfo.pageindex;

    var mData = {
        'pageNumber': json.pageInfo.pageindex,
        'pageSize': json.pageInfo.pagesize,
        'tag': json.dataOption.dataTag,
        'scope': json.dataOption.dataScope,
        'query': json.query,
        'c': json.cityCode
    };
    //加载前先暂停滚动加载
    off();
    $.ajax({
        url: '/ss/api/list',
        type: 'GET',
        data: $.param(mData) + '&' + json.urlQuery,
        cache: false,
        dataType: 'json',
        beforeSend: function () {
            startTime = new Date().getTime();
        },
        complete: function () {
            endTime = new Date().getTime();
            // 统计列表接口返回的时间 by lvjiran 2015-11-27
            alog('cus.fire', 'time', {z_ssItem: endTime - startTime});
        },
        success: function (res) {
            var result = res.result.data;
            if (res.errNo === 0) {
                if (isAjax) {
                    $('#filterBox').addClass('hide');
                    $('#marsk').addClass('hide');
                    if (result.length) {
                        displayNavList(result, true);
                        //重设分页参数
                        json.pageInfo.docHeight = $(document).height();
                        json.pageInfo.total = res.result.total;
                        json.pageInfo.pageindex = 1;
                        pageLogic();
                        if (res.result.total > 10) {
                            $(json.pageInfo.loading).show();
                            $(json.pageInfo.bottmTip).hide();
                        } else {
                            $(json.pageInfo.loading).hide();
                            $(json.pageInfo.bottmTip).show();
                        }
                    } else {
                        $(json.pageInfo.bottmTip).hide();
                        $(json.pageInfo.loading).hide();
                        noResultHtml = '<li class="no-result">搜不出想要的结果?<br>试试其它筛选条件吧</li>';
                        $('#nav-list').html(noResultHtml);
                    }   
                } else {
                    // 滚动时获取数据
                    if (result.length) {
                        displayNavList(result);
                        //重设页面高度
                        json.pageInfo.docHeight = $(document).height();
                        //渲染完毕，如果还有下一页，则重新开启自动加载
                        if (json.pageInfo.pageindex < json.pageInfo.ttPage) {
                            on();
                        } else {
                            $(json.pageInfo.bottmTip).show();
                        }
                    }
                }
            }
        },
        error: function () {
            /*暂时先去掉*/
            /*alert('系统错误，请稍后重试！');*/
        }
    });
}

/**
 * 渲染列表
 * @param {Array} data 每页数据
 * @param {string} isAjax:true 点击后ajax获取列表数据
 */
function displayNavList(data, isAjax) {
    var navList = $('#nav-list');
    var listHtml = '';
    var template = __inline('./list.tmpl');
    listHtml = template({
        data: data,
        listConfig: json.listConfig
    });
    if (isAjax) {
        navList.html('');
    }
    navList.append(listHtml);
}

/**
 * 事件绑定
 */
function bindEvent() {
    var order = null;

    // 定位不到当前城市引导层点击事件
    $('#lead-close').on('click', function() {
        $(this).hide();
    });
    $('#filterBox .filter-items li').on('click', function () {
        var target = $(this);
        target.siblings().removeClass('active');
        target.addClass('active');
        var dataTag = target.attr('data-tag');
        var dataScope = target.attr('data-scope');
        if (dataTag !== null) {
            json.dataOption.dataTag = dataTag;
        }
        if (dataScope !== null) {
            json.dataOption.dataScope = dataScope;
        }
        // 关闭弹层内容高度自适应
        $('.wrapper').css({
            height: 'auto',
            overflowY: 'auto'
        });
        getNavList(true);
    });
}

/**
 * 初始化页面
 */
function init(option) {
    json.pageInfo.total = option.pageInfo.total;
    json.query = option.query;
    json.urlQuery = option.urlQuery;
    json.listConfig = option.listConfig;
    json.cityCode = option.cityCode;
    
    // 事件绑定
    bindEvent();
    // 分页逻辑
    pageLogic();
}

exports.init = init;

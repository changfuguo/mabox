/**
 * 弹窗
 * @author  Your Name (you@example.org)
 * @date    2015-07-14 19:15:57
 * @version 1.0
 */
var dialogTmpl = __inline('./dialog.tmpl');
var dialogEle = null;
var dialogMain = null;
var Dialog = {
    /**
     * 绑定按钮事件
     * 
     * @param  {[type]} btns [description]
     * @return {[type]}      [description]
     */
    bindBtnEvent: function(btns) {
        var btnsEle = dialogMain.children('.dialog-btns');
        btnsEle.off('click');
        btnsEle.on('click', 'a', function(e) {
            var curBtn = $(this);
            btns[curBtn.index()].callback();
        });
    },
    /**
     * 初始化弹窗
     * 
     * @param  {[type]} opts [description]
     * @return {[type]}      [description]
     */
    init: function(opts) {
        var me = this;
        var dialogHeight = 0;
        var btnsHtml = '';
        if (dialogEle) {
            dialogMain.children('.dialog-title').html(opts.title);
            dialogMain.children('.dialog-content').html(opts.content);
            if (opts.btns.length > 0) {
                for (var i = 0, len = opts.btns.length; i < len; i++) {
                    btnsHtml = btnsHtml + '<a href="javascript:;">' + opts.btns[i].text + '</a>';
                }
                dialogMain.children('.dialog-btns').html(btnsHtml);
                dialogMain.children('.dialog-btns').show();
            }
        } else {
            dialogEle = $(dialogTmpl(opts));
            $(document.body).append(dialogEle);
            dialogMain = dialogEle.children('.dialog-wrap');
        }
        if (opts.btns.length > 0) {
            me.bindBtnEvent(opts.btns);
        } else {
            dialogMain.children('.dialog-btns').hide();
        }
    },
    resizeDialogPos: function() {
        var dialogHeight = dialogMain.height();
        var winHeight = document.documentElement.clientHeight;
        var bodyHeight = document.documentElement.scrollHeight;
        dialogMain.css('margin-top', -Math.ceil(dialogHeight / 2));
        dialogEle.children('.dialog-mask').height(winHeight > bodyHeight ? winHeight : bodyHeight);
    },
    /**
     * 显示弹窗
     * 
     * @param  {[type]} opts [description]
     * @return {[type]}      [description]
     */
    show: function(opts) {
        var me = this;
        me.init(opts);
        dialogEle.show();
        me.resizeDialogPos();
    },
    /**
     * 隐藏弹窗
     * 
     * @return {[type]} [description]
     */
    hide: function() {
        dialogEle.hide();
    }
};
module.exports = Dialog;
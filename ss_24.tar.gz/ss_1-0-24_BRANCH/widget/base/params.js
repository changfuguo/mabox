var NAParam =(function(){ 

    var toString = Object.prototype.toString;
    var slice = Array.prototype.slice
    /*
     * @desc get value from url
     * @param{string} url
     * @param{string} name
     * @return{string}
     */
    function getValue(url, name) {    
        var reg = new RegExp('(\\?|&)' + name + '=([^&?]*)', 'i');    
        var arr = url.match(reg);    
        if (arr) {        
            return arr[2];    
        }   
        return null;
    }

    /*
     * @desc get all key-value from url
     * @param{url} url
     * @return{Object}
     */
    function getKeyValue(url) {    
        var result = {};    
        var reg = new RegExp('([\\?|&])(.+?)=([^&?#]*)', 'ig');    
        var arr = reg.exec(url);    
        while (arr) {        
            result[arr[2]] = arr[3];        
            arr = reg.exec(url);    
        }    
        return result;

    }
    
    
    var innerParams = ['oem', 'channel','ldata','cpu','','sv','os','resid','mb','net','ctm','glr','bduid','dpi','webview_apply_webback','from','glv','ver','screen','cuid'];
   
    /*
     * @desc get inner params from na
     * @return{Object}
     */
    function getInnerParams(){
        var params = getKeyValue(location.search);

        var iParams = {};
        innerParams.reduce(function(dest, attr){
            dest[attr] = params[attr];
            return dest;
        },iParams);
    
        return iParams;
        
    }

    function extend(obj){
        var args = slice.call(arguments, 1);

        args.forEach(function(source){
            if(source){      
                for(var attr in source){
                    obj[attr] = source[attr];
                }
            }
        })
    }
    var ls_key_na_param = 'ss_native_params';
    var ls = window.localStorage;

    function is(obj, type){
        return toString.call(obj).toLowerCase() == '[object '+ type +']';
    }
    function write(params){
        if(!ls){
            return false;
        }
        if(is(params,'string')){
            params = getKeyValue(params);
        } else if(is(params,'function')) {
            params = params();
        } 
        
        
       
       var oldParams = {};
        try{
            oldParams = JSON.parse(ls.getItem(ls_key_na_param)); 
        }catch(e){
            oldParams = params;
        }
        if(!oldParams){
            oldParams = params;
        }

        for(var attr in params) {
            if (params.hasOwnProperty(attr) && innerParams.indexOf(attr) > -1) {
                oldParams[attr] = params[attr];
            }
        } 
        
        ls.setItem(ls_key_na_param, JSON.stringify(oldParams));
    }
    /*
     * @desc read inner params from ls
     * @param{boolean} serialize
     * @return{string}
     */
    function read(serialize) {
        serialize = serialize === undefined ? true : !!undefined; 
        var oldParams = {};
        try{
            oldParams = JSON.parse(ls.getItem(ls_key_na_param)); 
        }catch(e){
            oldParams = null;
        }
        
        var st = [];
        if (serialize) {
            for(var attr in oldParams) {
                if (oldParams.hasOwnProperty(attr)) {
                    st.push(attr + '=' + oldParams[attr]);
                }
            }
            return st.join('&');
        } else {
            return oldParams;
        }
    }

    /*
     * @desc appendTo url
     * @param{string} url
     * @param{object} extraParams
     */
    function appendTo(url, extraParams) {
        
        var reg = new RegExp('([\\?|&])(.+?)=([^&?]*)', 'ig');    
        url = url || location.href;
        var oldParams = read(false);
        extraParams = extraParams || {};
        oldParams = extend(oldParams, extraParams);
        return url.replace(reg, function(matched, sep, key, value){
            return sep + key + '=' + (extraParams[key] || value);        
        })
    }
    return {
        write: write,
        read: read,
        appendTo: appendTo
    };
})();

/**
 * 工具方法类
 * Created by liumanwei on 14-5-16.
 */

//扩展String去除首尾空格函数
String.prototype.Trim = function(){
    return this.replace(/(^\s*)|(\s*$)/g, "");
};
var Util = {
    /**
     * wappass登录地址
     */
    wappassUrl:'http://wappass.baidu.com/?tpl=lbsugc&authsite=1&smsLoginLink=1&adapter=1&subpro=jifenshouyedenglu',
    /**
     * 根据key获取URL中查询参数的值
     * @param key
     * @returns {*}
     */
    getUrlQueryByKey: function(key) {
        var result = location.search.match(new RegExp("[\?\&]" + key + "=([^\&]+)", "i"));
        if (result == null || result.length < 1) {
            return "";
        }
        return result[1];
    },
    /**
     * 账号互通webview->native同步
     */
    wappassLoginSync: function() {
        var userAgent = window.navigator.userAgent,
            me = this;
        //是否来自webview的pass
        if(me.getUrlQueryByKey('fromPass') == 1){
            //版本是否支持账号同步
            if(userAgent.indexOf('baidumap_IPHO') !=-1 || userAgent.indexOf('baidumap_ANDR') != -1){
                window.location.href = 'bdapi://wappass_login.sync';
            }
        }
    },
    /**
     * 获取请求代理接口时传递的客户端参数
     * 目前没有用到，暂时不考虑改造这个by febody
     * @param isStr 是否转换成字符串形式 aa=bb&cc=dd
     * @returns {*}
     */
    getApiProxyQuery: function(isStr){
        var me = this;
            apiData = {
                'os': me.getUrlQueryByKey('os'),
                'mb': me.getUrlQueryByKey('mb'),
                'sv': me.getUrlQueryByKey('sv'),
                'cuid': me.getUrlQueryByKey('cuid')
            };
        if(isStr) {
            return $.param(apiData);
        } else {
            return apiData;
        }
    },
    /**
     * 获取URL中的sysbduss
     * 目前没有用到，暂时不考虑改造这个by febody
     * @param val 字段前是加?还是&
     * @returns {*}
     */
    getUrlBduss: function(val) {
        var me = this,
            urlBduss = me.getUrlQueryByKey('sysbduss');
        if(urlBduss.length > 0) {
            if(val == 'wh') {
                urlBduss = '?sysbduss=' + urlBduss;
            } else {
                urlBduss = '&sysbduss=' + urlBduss;
            }
        }
        return urlBduss;
    },
    /**
     * 一些URL中包含的客户端信息(与设备、账号等有关，一般不用于分享到外部使用)
     * by yangchunwen
     */
    sensitiveInfo: [
        'bduss',
        'loc',
        'c',
        'mb',
        'os',
        'sv',
        'net',
        'resid',
        'cuid',
        'bduid',
        'channel',
        'screen',
        'dpi',
        'ver',
        'ctm'
    ],
    /**
     * 删除URL中的敏感信息(用于分享URL等场合)
     * 目前没有用到，暂时不考虑改造这个by febody
     * @param val 字段前是加?还是&
     * @param null
     * @returns String
     * by yangchunwen
     */
    filterSensitiveInfoUrl: function () {
        var str = location.href;
        return this.filterSensitiveInfo(str);
    },
    filterSensitiveInfo: function (str) {
        var rst = str;
        this.sensitiveInfo.forEach(function (info, index) {
            var reg = new RegExp(info + '=[^\\?\\&]*\\&?');
            rst = rst.replace(reg, '');
        });
        return rst;
    },
    /**
     * 把页面中的低质量图片替换为高质量的原图
     * 目前没有用到，暂时不考虑改造这个by febody
     * <img src="low.png" data-src="high.png"> => <img src="high.png">
     * @author yangchunwen
     * @param {string}/{dom}图片的id或图片的dom
     * @param {function} 替换成功后的回调
     */
    replaceImg: function (imgId, callback) {
        var doc = document;
        var img = doc.createElement('img');
        var origin = imgId.nodeName ? imgId : doc.getElementById(imgId);
        var src = origin.getAttribute('data-src');
        img.className = origin.className;
        img.style.display = 'none';
        img.onload = function () {
            var parent = origin.parentNode;
            parent.replaceChild(img, origin);
            img.style.display = 'block';
            typeof callback === 'function' && callback.call(null, img);
        };
        img.src = src;
        doc.body.appendChild(img);
    },
    /**
     * 比较两个客户端版本的大小
     * 目前没有用到，暂时不考虑改造这个by febody
     * @author liumanwei
     * @param  {[type]} verson1 [description]
     * @param  {[type]} verson2 [description]
     * @return {[type]}         [description]
     */
    compareNAVersion: function(verson1, verson2) {
        var arrVersion1 = verson1.split('.'),
            arrVersion2 = verson2.split('.'),                                               
            numVersion1 = 0,
            numVersion2 = 0,
            i = 0, 
            len = 0;
        i = 0;
        len = arrVersion1.length;
        for(i = 0, len = arrVersion1.length; i < len; i++) {
            numVersion1 = numVersion1 + parseInt(arrVersion1[i]) * Math.pow(10, len - i);
        }
        i = 0;
        len = arrVersion2.length;
        for(i = 0, len = arrVersion2.length; i < len; i++) {
            numVersion2 = numVersion2 + parseInt(arrVersion2[i]) * Math.pow(10, len - i);
        }
        if(numVersion1 > numVersion2) {
            return 1;
        } else if(numVersion1 < numVersion2){
            return -1;
        } else {
            return 0;
        }
    },
    /**
     * 设置cookie
     * @author lvjiran
     * @param {string} name cookie的name
     * @param {string} val cookie的value
     * @param {string} iDay cookie过期时间
     */
    setCookie: function (name, val, iDay) {
        var oDate = new Date();
        oDate.setDate(oDate.getDate() + iDay);
        document.cookie = name + '=' + val + ';path=/;expires=' + oDate;
    },
    /**
     * 获取cookie
     * @author lvjiran
     * @param {string} arr2[1] 获取到的cookie值
     */
    getCookie: function (name) {
        var str = document.cookie;
        var arr = str.split('; ');
        for (var i = 0; i < arr.length; i++) {
            var arr2 = arr[i].split('=');
            if (arr2[0] == name) {
                return arr2[1];
            }
        }
        return false;
    },
    isAndroid: function () {
        return (/android/i).test(navigator.userAgent);
    },
    isIPhone: function () {
        return (/iphone/i).test(navigator.userAgent);
    },
    isIPad: function () {
        return (/ipad/i).test(navigator.userAgent);
    },
    isIPod: function () {
        return (/ipod/i).test(navigator.userAgent);
    },
    isIOS: function () {
        return (/iphone|ipad|ipod/i).test(navigator.userAgent); 
    },
    getNativeInfo: function () {
        var strQuery = decodeURIComponent(window.location.search.substring(1));
        var arrQuery = [];
        var objQuery = {};
        var temp = [];
        if (strQuery) {
            arrQuery = strQuery.split('&');
            for (var i = 0, len = arrQuery.length; i < len; i++) {
                temp = arrQuery[i].split('=');
                if ('channel|sv|os|resid|mb|net|cuid|c|loc'.indexOf(temp[0]) > -1) {
                    objQuery[temp[0]] = temp[1];
                }
            }
            return objQuery;
        }
        return null;
    },
    getOsType: function () {
        var me = this;
        var osType = '';
        if (me.isAndroid()) {
            osType = 'android';
        }
        if (me.isIPhone()) {
            osType = 'iphone';
        }
        if (me.isIPad()) {
            osType = 'ipad';
        }
        if (me.isIPod()) {
            osType = 'ipod';
        }
        return osType;
    },
    customAlert: function (content, timer) {
        var alertTemplte = '<div class="custom-alert">' + content + '</div>';
        var dialog = $('.custom-alert');
        if (dialog.length > 0) {
            dialog.html(content);
        } else {
            $(document.body).append(alertTemplte);
            dialog = $('.custom-alert');
        }
        dialog.show();
        dialog.css('margin-left', -(dialog.width() / 2));
        if (timer > 0) {
            setTimeout(function () {
                dialog.hide();
            }, timer);
        }
    }

}
module.exports = Util;

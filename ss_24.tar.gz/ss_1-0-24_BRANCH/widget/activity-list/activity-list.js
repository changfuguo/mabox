/**
 * @file 排行榜列表
 * @authors lvjiran
 * @date    2016-01-12 15:31:45
 * @version 1.0
 */
var util = require('ss:widget/base/util.js');
var stat = require('ss:widget/stat/stat.js');


var docHeight = document.documentElement.scrollHeight;
var json = {};
var noop = function () {};
/**
 * query: 请求接口参数
 * urlQuery: 获取客户端参数
 * types: 类别
 * pageInfo: 分页信息
 * dataOption: category 美食分类
 *             dataRank 排行类别
 */
var activeOrder = -1;
json = {
    query: '',
    urlQuery: '',
    types: '',
    cityCode: ''
};

json['pageInfo'] = {
    docHeight: docHeight,
    loading: '.loading',
    bottmTip: '#bottm-tip',
    ttPage: 0,
    total: 0,
    pagesize: 10,
    pageindex: 1
};

json['dataOption'] = {
    category: '',
    dataRank: ''
};

/**
 * 分页逻辑
 */
function pageLogic() {
    json.pageInfo.ttPage = Math.ceil(json.pageInfo.total / json.pageInfo.pagesize);
    if (json.pageInfo.pageindex >= json.pageInfo.ttPage) {
        return;
    }
    if (json.pageInfo.total > 10) {
        on();
    }
}

/**
 * 开启滚动加载
 */
function on() {
    $(json.pageInfo.loading).show();
    window.addEventListener('scroll', autoloadList);
}

/**
 * 暂停滚动加载
 */
function off() {
    $(json.pageInfo.loading).hide();
    window.removeEventListener('scroll', autoloadList);
}

/**
 * 滚动自动加载列表
 */
var container = $('#nav-list');
function autoloadList() {
    var clientHeight = document.documentElement.clientHeight;
    var scrollTop = document.body.scrollTop || document.documentElement.scrollTop;
    var bottom = json.pageInfo.docHeight - clientHeight;

    // 判断是否最后一条距离顶部 或者进来的时候在底部 两者都需要做判断
    if (bottom - scrollTop <= 43 || (container.offset().top  + container.height() < scrollTop + clientHeight)) {
        ++json.pageInfo.pageindex;
        // 滚动分页统计
        stat.addStat({
            'da_src': 'ssrankpg.ranklistscroll',
            'da_act': 'scroll'
        });
        getNavList();
    }
}

/**
 * 发请求获取列表数据
 * @param {string} isAjax:true 点击后ajax获取列表数据
 */
function getNavList(isAjax) {
    var startTime = '';
    var endTime = '';
    var noResultHtml = null;
    // 推荐模块id
    var rmdBox = $('#rmd-box');
    // 返回顶部按钮
    var toTop = $('.go-to-top');
    json.pageInfo.pageindex = isAjax ? 1 : json.pageInfo.pageindex;

    var mData = {
        pageNumber: json.pageInfo.pageindex,
        pageSize: json.pageInfo.pagesize,
        category: decodeURIComponent(json.dataOption.category),
        rank: decodeURIComponent(json.dataOption.dataRank),
        type: json.types,
        query: json.query,
        c: json.cityCode
    };
    // 加载前先暂停滚动加载
    off();
    $.ajax({
        url: json.url,
        type: 'GET',
        data: $.param(mData) + json.urlQuery,
        cache: false,
        dataType: 'json',
        beforeSend: function () {
            startTime = new Date().getTime();
        },
        complete: function () {
            endTime = new Date().getTime();
            // 统计列表接口返回的时间 by lvjiran 2016-01-12
            alog('cus.fire', 'time', {z_ssRankItem: endTime - startTime});
        },
        success: function (res) {
            var result = res.result.list;
            if (res.errNo === 0) {
                // 点击时发请求获取数据
                if (isAjax) {
                    if ($('#filterBox') && $('#marsk')) {
                        $('#filterBox').addClass('hide');
                        $('#marsk').addClass('hide');
                    }
                    if (result.length) {
                        displayNavList(result, true);
                        // 重设分页参数
                        json.pageInfo.docHeight = $(document).height();
                        json.pageInfo.total = res.result.total;
                        json.pageInfo.pageindex = 1;
                        pageLogic();
                        if (res.result.total > 10) {
                            $(json.pageInfo.loading).show();
                            // $(json.pageInfo.bottmTip).hide();
                            // 点击发请求后返回数据大于10条时底部推荐和返回顶部按钮不显示
                            if (rmdBox) {
                                rmdBox.hide();
                            }
                            if (toTop) {
                                toTop.hide();
                            }
                        } else {
                            $(json.pageInfo.loading).hide();
                            // $(json.pageInfo.bottmTip).show();
                            // 击发请求后返回数据小于等于10条时底部推荐和返回顶部按钮显示
                            if (rmdBox) {
                                rmdBox.show();
                            }
                            if (toTop) {
                                toTop.show();
                            }
                        }
                    } else {
                        // 无数据返回
                        // $(json.pageInfo.bottmTip).hide();
                        $(json.pageInfo.loading).hide();
                        noResultHtml = '<li class="no-result">搜不出想要的结果?<br>试试其它筛选条件吧</li>';
                        $('#nav-list').html(noResultHtml);
                        // 点击发请求后无数据返回底部推荐和返回顶部按钮显示
                        if (rmdBox) {
                            rmdBox.show();
                        }
                        if (toTop) {
                            toTop.show();
                        }
                    }
                } else {
                    // 滚动时发请求获取数据
                    if (result.length) {
                        displayNavList(result);
                        // 重设页面高度
                        json.pageInfo.docHeight = $(document).height();
                        // 渲染完毕，如果还有下一页，则重新开启自动加载
                        if (json.pageInfo.pageindex < json.pageInfo.ttPage) {
                            // 分页列表继续加载底部推荐和返回顶部按钮隐藏
                            if (rmdBox) {
                                rmdBox.hide();
                            }
                            if (toTop) {
                                toTop.hide();
                            }
                            on();
                        } else {
                            // $(json.pageInfo.bottmTip).show();
                            // 分页列表显示完全后底部推荐和返回顶部按钮显示
                            if (rmdBox) {
                                rmdBox.show();
                            }
                            if (toTop) {
                                toTop.show();
                            }
                        }
                    }
                }
            }
        },
        error: function () {
            /*暂时先去掉*/
            /*alert('系统错误，请稍后重试！');*/
        }
    });
}

/**
 * 渲染列表
 * @param {Array} data 每页数据
 * @param {string} isAjax:true 点击后ajax获取列表数据
 */
var template = __inline('./activity-list.tmpl');
function displayNavList(data, isAjax) {
    var navList = $('#nav-list');
    var listHtml = '';
    listHtml = template({
        data: data,
        config: {
            query: json.query,
            isAjax: isAjax
        }
    });
    if (isAjax) {
        navList.html('');
    }
    navList.append(listHtml);
    json.callback && json.callback();
}

/*
 * abstract params from url query
 */
function abstractParams(url, exclude) {
    url = url.replace(/^&/g, '');
    var params = url.split('&');
    var ret = {};
    exclude = exclude || [];
    params.forEach(function (v, i) {
        var param = v.split('=');
        var key = param[0];
        var value = param[1];
        if (exclude.length > 0 && exclude.indexOf(key) < 0) {
            ret[key] = value;
        }
    });
    params = [];
    for (var attr in ret) {
        if (ret.hasOwnProperty(attr)) {
            params.push(attr + '=' + ret[attr]);
        }
    }
    return params.join('&');
}
/**
 * 事件绑定
 */
function bindEvent() {

    // 热门菜排行榜点击
    $('.rank-hot-box').on('click', function () {
        var category = $(this).attr('data-category');
        var order = $(this).attr('data-order');
        if (category !== null) {
            json.dataOption.category = category;
        }
        var url = '/ss/page/rank?style=2&query='
                + json.query
                + '&type='
                + json.types
                + '&category='
                + json.dataOption.category
                + '&rank='
                + json.dataOption.dataRank
                + '&' + abstractParams(json.urlQuery, ['style', 'type', 'category', 'rank']);
        // 热门菜排行榜点击统计
        stat.normalOpenAndStat(url, {
            'da_src': 'ssrankpg.brandlistitem_' +  order,
            'da_act': 'click'
        });
    });

    // 分类排行榜tab点击事件
    $('#rank-nav li').on('click', function () {
        $('#rank-nav li').removeClass('active');
        $(this).addClass('active');
        activeOrder = $(this).attr('data-order');
        var dataRank = $(this).attr('data-tag');
        if (dataRank !== null) {
            json.dataOption.dataRank = dataRank;
        }
        getNavList(true);
    });

    // 导航浮层点击列表
    $('#filterBox .filter-items li').on('click', function () {
        var target = $(this);
        target.siblings().removeClass('active');
        target.addClass('active');
        var category = target.attr('data-query');
        var dataRank = target.attr('data-tag');

        // category为null, 表示获取不到"data-query"属性,取最新全局的json.dataOption.category
        json.dataOption.category = (category !== null)
                                   ? category
                                   : json.dataOption.category;
        // dataRank为null, 表示获取不到"data-tag"属性,取最新全局的json.dataOption.dataRank
        json.dataOption.dataRank = (dataRank !== null)
                                   ? dataRank
                                   : json.dataOption.dataRank;
        // 选择类别tab文字改变函数
        function getTxtFn() {
            var txt = target.text();
            var id = target.parents('.filter-content-near').attr('id');
            var nav = $('#nav-select a');
            var filterNav = $('#filterBox .filter-nav a');

            for (var i = 0; i < filterNav.size(); i++) {
                if (filterNav.eq(i).attr('data-href') === ('#' + id)) {
                    filterNav.eq(i).find('span').text(txt);
                    nav.eq(i).find('span').text(txt);
                }
            }
        }
        getTxtFn();
        // 关闭弹层内容高度自适应
        $('.wrapper').css({
            height: 'auto',
            overflowY: 'auto'
        });
        getNavList(true);
    });
}

/**
 * 初始化页面
 */
function init(option) {
    json.pageInfo.total = option.pageInfo.total;
    json.types = option.types;
    json.query = option.query;
    json.callback = option.callback || noop;
    json.url = option.url || '/ss/api/rank/'; 
    json.urlQuery = option.urlQuery.replace(/query=[^&]*/ig, '').replace(/&type=[^&]*/ig, '').replace(/&category=[^&]*/ig, '').replace(/&rank=[^&]*/ig, '');
    if (json.urlQuery.charAt(0) !== '&') {
        json.urlQuery = '&' + json.urlQuery;
    }
    if (activeOrder === -1) {
        activeOrder = $('#rank-nav li.active').attr('data-order');
    }
    json.cityCode = option.cityCode;
    json.dataOption.category = util.getUrlQueryByKey('category');
    json.dataOption.dataRank = util.getUrlQueryByKey('rank');
    // 事件绑定
    bindEvent();
    // 分页逻辑
    pageLogic();
}

exports.init = init;

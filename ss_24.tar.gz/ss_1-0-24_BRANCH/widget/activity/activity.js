/**
 * @file 活动页
 * @authors lvjiran
 * @date    2015-12-09 15:41:45
 * @version 1.0
 */
var util = require('ss:widget/base/util.js');
var stat = require('ss:widget/stat/stat.js');

module.exports = {
    /**
     * 当前页统计参数
     */
    statParam : {
        // 检索聚合活动页
        'showActivitypg': {
            'da_src': 'ssactivitypg',
            'da_act': 'show'
        },
        // 头部去搜索按钮点击
        'searchBtnClick': {
            'da_src': 'ssactivitypg.searchbt',
            'da_act': 'click'
        },
        // 品牌模块列表点击
        'brandListClick': {
            'da_src': 'ssactivitypg.brandlistitem',
            'da_act': 'click'
        },
        // 人气模块列表点击
        'hotListClick': {
            'da_src': 'ssactivitypg.hotlistitem',
            'da_act': 'click'
        }
    },
    /**
     * 获取浏览器内核信息
     */
    'ua': navigator.userAgent.toLowerCase(),

    /**
     * 事件绑定
     */
    bindEvent: function () {
        var me = this;

        // 头部去搜索按钮点击
        $('.act-search').on('click', function () {
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['searchBtnClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['searchBtnClick']);
            }
        });
        // 品牌模块列表点击
        $('.act-brand-box').on('click', function () {
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['brandListClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['brandListClick']);
            }
        });
        // 人气模块列表点击
        $(document.body).on('click', '.act-list-container .act-list', function () {
            // webapp跳转地址
            var webAppUrl = $(this).attr('data-webapp-url');
            // NA端跳转地址
            var nativeUrl = $(this).attr('data-native-url');
            if (me.ua.indexOf('baidumap_ipho') !== -1 || me.ua.indexOf('baidumap_andr') !== -1) {
                stat.normalOpenAndStat(nativeUrl, me.statParam['hotListClick']);
            } else {
                stat.normalOpenAndStat(webAppUrl, me.statParam['hotListClick']);
            }
        });
    },

    /**
     * 初始化页面
     */
    init: function () {
        var me = this;
        me.bindEvent();
        util.wappassLoginSync();
        // 检索聚合首页统计pv/uv
        stat.addStat(me.statParam['showActivitypg']);
    }
};

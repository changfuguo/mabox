/**
 * 前端脚本发生错误时，发送一条LOG到日志里
 * Created by liumanwei on 14-6-5.
 */
var util = require('ss:widget/base/util.js');
module.exports = {
    /**
     * 绑定脚本发生错误时的事件
     */
    bindEvent: function() {
        window.onerror = function(message, url, line) {
            var ua = window.navigator.userAgent.toLowerCase();
            if(url == ''
                || url == 'undefined'
                || line == 0
                || message.indexOf('setInfo') > -1
                || message.indexOf('correctPOIInfo') > -1){
                return true;
            } else {
                var errorObj = $('#error-img'),
                    imgUrl = __uri('/static/images/transparent.gif'),
                    param = {
                        'message': encodeURIComponent(message),
                        'page': encodeURIComponent(url),
                        'line': encodeURIComponent(line),
                        'sv': encodeURIComponent(util.getUrlQueryByKey('sv')),
                        'os': encodeURIComponent(util.getUrlQueryByKey('os'))
                    };
                imgUrl = imgUrl + '?' + $.param(param);
                errorObj.attr('src', imgUrl);
                return true;
            }
        };
    },
    /**
     * 初始化
     */
    init: function() {
        var me = this;
        this.bindEvent();
    }
}

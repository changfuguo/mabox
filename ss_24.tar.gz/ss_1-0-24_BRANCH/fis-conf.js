/**
 * @file fis-config.js
 * @author changfuguo@baidu.com
 */
fis.require('smarty')(fis);
fis.set('namespace', 'ss');
/*
   fis.match('::package', {
    postpackager: fis.plugin('loader'),
});
*/
/*
 * set file for reading and ingore
 *
 */
fis.set('project.files',['**','.**','.**/**'])
    .set('project.ignore', ['**/_*.scss','.svn/**','fis-conf.js','BCLOUD','build.sh',"**.swp"])
    .set('project.ext', { scss: 'css'})
    // if use __inline ,may be cause smarty compile error
    // so add max len for compiler for uglify-js and clean-css
    .set("settings.optimizer.uglify-js", {
        output : {
            max_line_len : 500
        }
    })
    .set('settings.optimizer.clean-css',  { keepBreaks : true })
    .set('framework', {
        cache: false,
        combo: false
    });

/*
 *  code style
 */
fis.match('*.js', {
    useHash: true,
    optimizer: fis.plugin('uglify-js', {})
});
fis.match('*.css', {
    useHash: true,
    optimizer: fis.plugin('clean-css')
});
fis.match(/([^_\/]+).scss$/, {
    rExt: '.css',
    optimizer: fis.plugin('clean-css'),
    parser: fis.plugin('node-sass', {})
});

fis.match('**.tmpl', {
    isJsLike: true,
    parser: fis.plugin('bdtmpl')
});

/*
 * file packager 
 */

fis.set('pack',{
    '/pkg/base.js':[
        'static/js/libs/{mod,BigPipe,page,lazyload,rsvp}.js',
        'static/js/libs/{zepto,delayload,NativeAdapter}.js',
        'static/js/libs/template.js',
        'widget/base/util.js',
        'widget/stat/stat.js'
    ],
    '/pkg/base.css':[
        'widget/base/base.scss',
        'widget/dialog/dialog.scss'
    ],
    '/pkg/index.css': [
        'widget/{activity,activity-list,activity-search,favorites,nav,rank,rank-hot,recommend,serror,to-top}/*.scss'
    ],
    '/pkg/index.js': [
        'widget/{activity,activity-list,activity-search,favorites,nav,rank,rank-hot,recommend,serror,to-top}/*.js'
    ],
    '/pkg/mabox.js':[
        'static/js/mabox/core.js', 
        'static/js/mabox/cookie.js', 
        'static/js/mabox/utils.js', 
        'static/js/mabox/url.js', 
        'static/js/mabox/bridge.js' 
    ]
});

/*

fis.match('static/js/libs/{template,zepto,delayload}.js', {
    packTo: 'pkg/base.js'
});

fis.match('static/js/util.js', {
    packTo: 'pkg/base.js'
});
fis.match('widget/stat/stat.js', {
    packTo: 'pkg/base.js'
});

fis.match('static/js/libs/{mod,BigPipe,page,lazyload}.js', {
    packTo: 'pkg/fisBase.js'
});
*/
/*
fis.match('widget/base/base.scss', {
    packTo: 'pkg/base.css'
});
fis.match('widget/dialog/dialog.scss', {
    packTo: 'pkg/base.css'
});
*/

fis.match('widget/main/**.scss', {
    packTo: 'pkg/index.css'
});
fis.match('widget/info/{info,list}.scss', {
    packTo: 'pkg/index.css'
});
fis.match('widget/recommend/recommend.scss', {
    packTo: 'pkg/index.css'
});

/*
 * fis release style
 */
fis
    .match(/^\/(?:page|widget)\/.*\.tpl$/i, {
        release: '/template/${namespace}/$0',
    })
    .match(/^\/static\/(.*\.(?:js|css|eot|ttf|woff|gif|png|jpg$))/i, {
        release: '/static/${namespace}/$1',
    })
    .match(/^(\/(?:widget|pkg)\/.*\.(?:js|css|scss))$/i, {
        release: '/static/${namespace}$1',
    })
    .match('/config/(**.php)', {
        release: '/config/ss/$1',
    })
    .match('/plugin/(**.php)', {
        release: '/baiduplugins/$1',
    })
    .match('(${namespace}-map.json)', {
        release: '$1',
    });

    var deploy = {
    cfg: {
        receiver: 'http://cp01-msg-mcp-web-1.epc.baidu.com:8080/receiver.php',
        path: '/home/work/odp/'
    },
    hhs: {
        receiver: 'http://cp01-rdqa-dev415.cp01.baidu.com:8880/receiver.php',
        path: '/home/users/huanghongsen/odp_ss/'
    },
    wl: {
        receiver: 'http://cp01-sys-rath3-c32-qa00.cp01.baidu.com:8083/receiver.php',
        path: '/home/map/qa/guhua/odp/'
    }
};
// deploy
for (var attr in deploy) {
    if (!deploy.hasOwnProperty(attr)) {
        return false;
    }
    var person = deploy[attr];
    fis.media(attr)
       .match('*.js', {
            optimizer: null
        })
        .match('/static/js/libs/flexible.js', {
            optimizer: fis.plugin('uglify-js', {})
        })
        .match(/^\/(?:page|widget)\/.*\.tpl$/i, {
            deploy: fis.plugin('http-push', {
                receiver: person.receiver,
                subOnly: true,
                to: person.path
            })
        })
        .match(/^\/static\/(.*\.(?:js|css|eot|ttf|woff|gif|png|jpg$))/i, {
            deploy: fis.plugin('http-push', {
                receiver: person.receiver,
                subOnly: true,
                to: person.path + 'webroot'
            })
        })
        .match(/^(\/(?:widget|pkg)\/.*\.(?:js|css|scss))$/i, {
            deploy: fis.plugin('http-push', {
                receiver: person.receiver,
                subOnly: true,
                to: person.path + 'webroot'
            })
        })
        .match('/config/(**.php)', {
            deploy: fis.plugin('http-push', {
                receiver: person.receiver,
                subOnly: true,
                to: person.path + 'data/smarty'
            })
        })
        .match('/plugin/(**.php)', {
            deploy: fis.plugin('http-push', {
                receiver: person.receiver,
                subOnly: true,
                to: person.path + 'data/smarty'
            })
        })
        .match('(${namespace}-map.json)', {
            deploy: fis.plugin('http-push', {
                receiver: person.receiver,
                to: person.path + 'data/smarty/config'
            })
        });
}

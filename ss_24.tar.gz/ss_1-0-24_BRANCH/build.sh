#!/bin/bash

MOD_NAME="output"
TAR="$MOD_NAME.tar.gz"

rm -rf output
# add path
export PATH=/home/fis/npm/bin:$PATH
#show fis-plus version
fis3 --version --no-color

#通过fis-plus release 命令进行模块编译 开启optimize、md5、打包功能，同时需开启-u 独立缓存编译方式，产出到同目录下output中
fis3 release -d output --no-color

#进入output目录
cd output

mkdir webroot
cp -r ./static ./webroot/

mkdir data
mkdir data/smarty
mv ss-map.json ./config
cp -r ./config ./data/smarty/

mkdir php
mkdir php/phplib
mkdir php/phplib/ext
mkdir php/phplib/ext/smarty
mv  ./baiduplugins ./php/phplib/ext/smarty/

#删除test、config、plugin、server-conf、static目录
rm -rf test
rm -rf config
rm -rf server-conf
rm -rf static

# 删除svn 文件
find . -type d -name '.svn' |xargs rm -rf
#将output目录进行打包
tar zcf $TAR ./*
mv $TAR ../

cd ..
rm -rf output

mkdir output
mv $TAR output/

#rm -rf output
echo "build end"
